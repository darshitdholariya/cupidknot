import 'package:cupid/application/constants.dart';
import 'package:cupid/presentation/router/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../application/string.dart';

class RegisterScreen extends StatelessWidget {
  RegisterScreen({Key? key}) : super(key: key);
  TextEditingController? email = TextEditingController();
  TextEditingController? name = TextEditingController();
  TextEditingController? pass = TextEditingController();
  TextEditingController? conPass = TextEditingController();
  TextEditingController? mob = TextEditingController();
  TextEditingController? gender = TextEditingController();
  TextEditingController? dob = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: SizedBox(
            height: 1.sh,
            width: 1.sw,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40).r,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        Strings.register,
                        style: Const.bold.copyWith(
                            color: const Color.fromRGBO(49, 39, 79, 1),
                            fontWeight: FontWeight.bold,
                            fontSize: 30.sp),
                      ),
                      SizedBox(
                        height: 30.h,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Const.kWhite,
                            boxShadow: const [
                              BoxShadow(
                                color: Color.fromRGBO(196, 135, 198, .3),
                                blurRadius: 20,
                                offset: Offset(0, 10),
                              )
                            ]),
                        child: Column(
                          children: <Widget>[
                            TextField_Register(
                              hint: Strings.name,
                              controller: name,
                            ),
                            TextField_Register(
                              hint: Strings.email,
                              controller: email,
                            ),
                            TextField_Register(
                              hint: Strings.phone,
                              controller: mob,
                            ),
                            TextField_Register(
                              hint: Strings.password,
                              controller: pass,
                            ),
                            TextField_Register(
                              hint: Strings.conPass,
                              controller: conPass,
                            ),
                            TextField_Register(
                              hint: Strings.gender,
                              controller: gender,
                            ),
                            TextField_Register(
                              hint: Strings.dob,
                              controller: dob,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      Container(
                        height: 50,
                        margin: const EdgeInsets.symmetric(horizontal: 60),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: const Color.fromRGBO(49, 39, 79, 1),
                        ),
                        child: Center(
                          child: Text(
                            Strings.register,
                            style: Const.bold.copyWith(color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pushNamedAndRemoveUntil(
                            context, AppRouter.login, (route) => false),
                        child: Center(
                            child: Text(
                          Strings.alreadyAc,
                          style: Const.medium.copyWith(
                              color: const Color.fromRGBO(49, 39, 79, .6)),
                        )),
                      ),
                    ],
                  ),
                ),
                const Spacer()
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class TextField_Register extends StatelessWidget {
  const TextField_Register({
    Key? key,
    this.hint,
    this.controller,
  }) : super(key: key);
  final String? hint;
  final TextEditingController? controller;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10).r,
      decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: Colors.grey[200]!))),
      child: TextField(
        decoration: InputDecoration(
            border: InputBorder.none,
            hintText: hint,
            hintStyle: Const.medium.copyWith(color: Colors.grey)),
      ),
    );
  }
}
