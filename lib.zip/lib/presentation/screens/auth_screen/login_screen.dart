import 'package:cupid/application/constants.dart';
import 'package:cupid/gen/assets.gen.dart';
import 'package:cupid/presentation/router/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../application/string.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            const Spacer(),
            Hero(
              tag: 'LOGIN',
              child: Center(
                child: SizedBox(
                  height: 80.h,
                  width: 80.w,
                  child: Assets.image.contacts.image(width: 60.w, height: 60.h),
                ),
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40).r,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    Strings.login,
                    style: Const.bold.copyWith(
                        color: const Color.fromRGBO(49, 39, 79, 1),
                        fontWeight: FontWeight.bold,
                        fontSize: 30.sp),
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.r),
                        color: Const.kWhite,
                        boxShadow: [
                          BoxShadow(
                            color: const Color.fromRGBO(196, 135, 198, .3),
                            blurRadius: 20.r,
                            offset: const Offset(0, 10),
                          )
                        ]),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.all(10).r,
                          decoration: BoxDecoration(
                              border: Border(
                                  bottom:
                                      BorderSide(color: Colors.grey[200]!))),
                          child: TextField(
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: Strings.email,
                                hintStyle:
                                    Const.medium.copyWith(color: Colors.grey)),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(10).r,
                          child: TextField(
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: Strings.password,
                                hintStyle:
                                    Const.medium.copyWith(color: Colors.grey)),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20.h,
                  ),
                  Center(
                      child: Text(
                    Strings.forgetPass,
                    style: Const.medium.copyWith(
                        color: const Color.fromRGBO(196, 135, 198, 1)),
                  )),
                  const SizedBox(
                    height: 30,
                  ),
                  Container(
                    height: 50.h,
                    margin: const EdgeInsets.symmetric(horizontal: 60),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: Const.kheader,
                    ),
                    child: Center(
                      child: Text(
                        Strings.login,
                        style: Const.bold.copyWith(color: Colors.white),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30.h,
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pushNamedAndRemoveUntil(
                        context, AppRouter.register, (route) => false),
                    child: Center(
                        child: Text(
                      Strings.createAc,
                      style: Const.medium.copyWith(color: Const.kheader),
                    )),
                  ),
                ],
              ),
            ),
            const Spacer()
          ],
        ),
      ),
    );
  }
}
